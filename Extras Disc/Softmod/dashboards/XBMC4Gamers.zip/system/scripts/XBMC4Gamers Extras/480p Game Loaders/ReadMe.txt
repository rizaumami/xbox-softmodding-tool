Please patch your games via DVD2Xbox, either after installing one of the loaders or before hand.
( also make sure ACL patching is enabled in the settings of DVD2Xbox )


-- 480p Game Loader (CDX)
	-	Arctic Thunder
	-	Battle Engine Aquila
	-	Commandos 2
	-	Dark Summit
	-	Galleon
	-	Gun Metal
	-	Hunter The Reckoning: Redemption
	-	Jet Set Radio Future
	-	Metal Slug 3 ( must be patched - Hex search = 8B5728508B4730508B472C518B4F0452 - Replace with = 508B4730508B472C518B4F04906A0090 )
	-	Mission Impossible
	-	MLB Slugfest 20-03
	-	Night Caster
	-	Over the Hedge
	-	Quantum Redshift
	-	Serious Sam
	-	Tetris Worlds
	-	The Sims 2
	-	Tony Hawk's Pro Skater 3
	-	Voodoo Vince


-- 480p Game Loader (Evox)
	-	Fable


-- 480p Game Loader (PD1)
	-	Gun Valkyrie
	-	Panzer Dragoon Orta
	-	Wreckless: The Yakuza Missions



-- These games will not play on Xbox version 1.6 in HD mode --

-- Graphical Issues
	-	Hello Kitty - Screen is undersized in places.
	-	Jacked - Screen is undersized in places.
	-	Max Payne - Screen is oversized. ( works fine if screen size is set to normal )

-- Other Issues
	-	Dennou Taisen DroneZ - Won't unscramble in HD.
	-	Men of Valor - Restarts the game when selecting a mission.
	-	Pirates of the Caribbean - Won't unscramble.

-- Freezing on Load
	-	Curse: The Eye of Isis - Freezes on load.
	-	Headhunter - Redemption - Freezes on load.
	-	Outlaw Golf - 9 More Holes of X-Mas - Freezes on load.
	-	Secret Weapons Over Normandy - Freezes on load.
	-	Spartan: Total Warrior - Freezes on load.
	-	Tecmo Classic Arcade - Freezes on load.