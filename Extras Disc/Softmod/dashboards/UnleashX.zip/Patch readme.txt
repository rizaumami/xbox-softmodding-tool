UnleashX V0.39.0528 Build 584 Unofficial

I patched the xbe so that all FTP programs work with this build of UX. I also changed the internal zips and moved the contents round to make extraction and replacement simpler.



Skin zip offset
00602E00 entry in xbe file 076C - size C52C

Old
002E6000	00002CC5
New
002DFC1C	00002CC5

Assets offset
00A02600 entry in xbe file 06FC - size 1FA20500

Old
0026A000	0005A21F
New
0028B000	00053D9C
			

Icon offset
00502C00 entry in xbe file 0734 - size 00100200

Old
002C5000	00021000
New
0026A000	00021000