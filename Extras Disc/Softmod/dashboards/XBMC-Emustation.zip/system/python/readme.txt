python directory structure

DLLs dir:
  Library directory used by python.
  python exensions (.pyd) from cvs can be placed here
  
Lib dir:
  Library directory used by python.
  Here can new packages or modules be installed by the user.

Spyce dir:
  Here is where the Spyce installation remains, this is only there for use with psp (python server pages)
  on the goahead webserver.

dev note:
unicodedata.pyd is taken from a window installation, so you won't find the source in cvs for it