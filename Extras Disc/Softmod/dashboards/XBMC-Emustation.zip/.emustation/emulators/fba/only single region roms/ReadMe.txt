Place the Roms folder with all the roms zips inside and drag it onto the batch file.

There will be a new folder created called Transfer to Xbox, this will have all the single region roms inside.

The old roms folder will have all the bootleg and dups.