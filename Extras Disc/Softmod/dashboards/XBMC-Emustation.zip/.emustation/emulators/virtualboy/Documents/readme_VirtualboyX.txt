VirtualBoyX - Virtual Boy Emulator for XBox v3

http://mednafen.com/
http://xport.xbox-scene.com
goto http://www.emuxtras.net/ for latest cheats, rumbles, synopsis and skin updates.

What's New:

Check the Latest-VirtualboyX.txt file for the latest update info.  From now on it will have the latest info and this file will contain the changelog/older update information.


-----------------------------------------------------------------------

VirtualBoyX - Virtual Boy Emulator for XBox v2

http://xport.xbox-scene.com/
http://www.vr32.de/modules/tech/index.php?sec=emus&eid=rdragon

What's new:

*****************************
* Interface Related Changes *
*****************************

 - Updated core UI to most recent feature set


-----------------------------------------------------------------------

VirtualBoyX - Virtual Boy Emulator for XBox v1

http://xport.xbox-scene.com/
http://www.vr32.de/modules/tech/index.php?sec=emus&eid=rdragon

Features:

 - Emulates the Nintendo Virtual Boy

 - Excellent compatibility - ported from Red Dragon

 - Sound

Notes
-----

Put games in the \VBROMS directory

Rather slow, but very playable with 2-3 frameskip.


*****************************
* Interface Related Changes *
*****************************

 - All standard XPort features

 - ZIP/Relax/SMB support

 - Save states
